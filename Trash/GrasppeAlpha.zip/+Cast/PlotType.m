classdef PlotType
  %PLOTTYPE Summary of this function goes here
  %   Detailed explanation goes here
  
  enumeration
    Surface   ('surf')
    
  end
  
end

