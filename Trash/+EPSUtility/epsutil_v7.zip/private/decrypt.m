%DECRYPT   Decrypt encrypted text in Post Script
%   DECRYPT(DATA,KEY) takes uint8 DATA array and uint16 KEY and returns the
%   decrypted text

% Copyright 2012 Takeshi Ikuma
% History:
% rev. - : (03-04-2012) original release
% rev. 1 : (03-15-2012) revised the help text
