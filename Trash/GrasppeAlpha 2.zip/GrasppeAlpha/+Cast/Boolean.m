classdef Boolean < logical
   enumeration
      No  (0)
      Yes (1)
      off (0)
      on  (1)
   end  
end
