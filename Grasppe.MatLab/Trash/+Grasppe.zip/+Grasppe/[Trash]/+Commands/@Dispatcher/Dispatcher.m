classdef Dispatcher
  %DISPATCHER Command Initiator & Chain-of-Responsibility Client
  %   Initiates the request to a ConcreteHandler object (may be on the chain)
  
  properties
  end
  
  methods
  end
  
end

