classdef HandleBoolean < logical
  %HANDLEBOOLEAN Summary of this function goes here
  %   Detailed explanation goes here
  
  enumeration
      off (0)
      on  (1)    
  end
  
  methods
    
  end
  
end
