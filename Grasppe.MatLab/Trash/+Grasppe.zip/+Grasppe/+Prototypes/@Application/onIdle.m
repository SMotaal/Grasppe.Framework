function onIndle( obj, src, evt )
  %ONLAUNCHING Execute when Application is Paused
  %   Detailed explanation goes here
  
  Grasppe.Prototypes.Utilities.StampEvent(obj, src, evt);
  
end

