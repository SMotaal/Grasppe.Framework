function onLaunching( obj, src, evt )
  %ONLAUNCHING Execute after Application Initialized
  %   Detailed explanation goes here
  
  Grasppe.Prototypes.Utilities.StampEvent(obj, src, evt);
end

