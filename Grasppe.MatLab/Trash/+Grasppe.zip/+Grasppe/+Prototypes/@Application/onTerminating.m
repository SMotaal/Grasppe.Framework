function onTerminating( obj, src, evt )
  %ONLAUNCHING Execute when Application is Quitting
  %   Detailed explanation goes here
  
  Grasppe.Prototypes.Utilities.StampEvent(obj, src, evt);
  
end

