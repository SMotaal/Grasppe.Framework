function [ output_args ] = Quit( input_args )
  %QUIT Summary of this function goes here
  %   Detailed explanation goes here
  
  
end

