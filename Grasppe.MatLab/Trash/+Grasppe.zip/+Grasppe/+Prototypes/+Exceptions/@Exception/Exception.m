classdef Exception < Grasppe.Prototypes.Prototype & MException 
  
  properties
  end
  
  methods
  end
  
end
