classdef ProcessModel < Grasppe.Prototypes.Models.DataModel
  %OPERATIONDATA Summary of this class goes here
  %   Detailed explanation goes here
  
  properties
    Input
    Output    
  end
  
  methods
  end
  
end

