classdef TaskGroup < handle
  %TASKGROUP Superclass for Grasppe Core Prototypes 2
  %   Detailed explanation goes here
  
  properties
    % State     = Grasppe.Core.Enumerations.TaskStates.Initializing;
    % Progress  = [];
    % Status    = 'Initializing';
    
    Tasks       = Grasppe.Core.Prototypes.Task.empty;
  end
  
  methods
    
    
  end
  
  methods (Access=protected)
    
  end
  
end

