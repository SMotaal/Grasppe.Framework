classdef Model < Grasppe.Core.Prototypes.Component
  %MODEL Component Superclass for Grasppe Core Prototypes 2
  %   Detailed explanation goes here
  
  properties
  end
  
  methods
  end
  
end

