classdef Process < Grasppe.Core.Prototypes.Task
  %PROCESS Superclass for Grasppe Core Prototypes 2
  %   Detailed explanation goes here
  
  properties
  end
  
  methods
  end
  
end

