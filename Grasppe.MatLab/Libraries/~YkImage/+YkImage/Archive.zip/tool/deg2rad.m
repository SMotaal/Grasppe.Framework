function y = deg2rad(x)
% Convert degree to  radian
%
%
y = x * 2 * pi / 360;

