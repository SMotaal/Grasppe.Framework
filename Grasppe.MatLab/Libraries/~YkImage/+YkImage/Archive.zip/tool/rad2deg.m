function y = rad2deg(x)
% Convert radian to degree
%
%
y = x * (180/pi);
